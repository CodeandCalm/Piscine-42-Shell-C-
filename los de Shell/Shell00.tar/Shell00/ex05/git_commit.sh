git log --no-pager --pretty=format:%H -n5
